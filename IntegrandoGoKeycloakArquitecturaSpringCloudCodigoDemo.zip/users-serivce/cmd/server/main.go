package main

import (
	"os"
	"os/signal"
	"time"

	"github.com/gin-gonic/gin"
	"gitlab.com/tomas.pereyra/users-serivce/cmd/server/handler"
	"gitlab.com/tomas.pereyra/users-serivce/internal/user"
	"gitlab.com/tomas.pereyra/users-serivce/pkg/eureka"
	"gitlab.com/tomas.pereyra/users-serivce/pkg/middleware"
)

func main() {

	eureka.RegisterApp("1", "users-service")

	server := gin.Default()
	roles := []string{"USER", "ADMIN"}
	server.Use(middleware.IsAuthorizedJWT(roles))
	repository := user.NewRepository()
	service := user.NewService(*repository)
	handler := handler.NewUserHandler(*service)

	usersRoute := server.Group("/users")

	usersRoute.GET(":id", handler.FindById())

	eureka.UpdateAppStatus("1", "users-service", "UP")
	task := eureka.ScheduleHeartbeat("users-service", "1")

	c := make(chan os.Signal)
	signal.Notify(c, os.Interrupt)

	go func() {
		select {
		case signal := <-c:
			_ = signal
			task.Cancel()
			eureka.UpdateAppStatus("1", "users-service", "DOWN")
			time.Sleep(4 * time.Second)
			eureka.DeleteApp("1", "users-service")
			os.Exit(1)
		}
	}()

	server.Run(":8083")

}
