package handler

import (
	"errors"
	"strconv"

	"github.com/gin-gonic/gin"
	"gitlab.com/tomas.pereyra/users-serivce/internal/user"
	"gitlab.com/tomas.pereyra/users-serivce/pkg/web"
)

type UserHandler struct {
	service user.Service
}

func NewUserHandler(service user.Service) *UserHandler {
	return &UserHandler{
		service: service,
	}
}

func (userHandler *UserHandler) FindById() gin.HandlerFunc {

	return func(c *gin.Context) {
		idParam := c.Param("id")
		id, err := strconv.Atoi(idParam)
		if err != nil {
			web.Failure(c, 400, errors.New("invalid id"))
			return
		}
		web.Success(c, 200, userHandler.service.FindUserById(id))

	}
}
