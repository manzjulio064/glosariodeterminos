package domain

type User struct {
	Id             int    `json:"id"`
	Name           string `json:"name"`
	LastName       string `json:"lastName"`
	Identification string `json:"identification"`
}
