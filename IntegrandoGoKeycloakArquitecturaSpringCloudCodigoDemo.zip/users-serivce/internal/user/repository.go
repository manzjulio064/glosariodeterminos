package user

import (
	"gitlab.com/tomas.pereyra/users-serivce/internal/domain"
)

type Repository struct {
	database map[int]domain.User
}

func NewRepository() *Repository {
	var userA = domain.User{Id: 1, Name: "Tomas", LastName: "Pereyra", Identification: "21345311"}
	var users = map[int]domain.User{
		userA.Id: userA,
	}

	return &Repository{database: users}
}

func (repository *Repository) FindById(id int) domain.User {
	return repository.database[id]
}
