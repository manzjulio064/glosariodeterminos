package user

import (
	"gitlab.com/tomas.pereyra/users-serivce/internal/domain"
)

type Service struct {
	repository Repository
}

func NewService(r Repository) *Service {
	return &Service{r}
}
func (service *Service) FindUserById(id int) domain.User {
	return service.repository.FindById(id)
}
