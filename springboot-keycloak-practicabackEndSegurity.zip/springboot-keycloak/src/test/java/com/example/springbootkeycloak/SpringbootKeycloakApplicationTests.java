package com.example.springbootkeycloak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootKeycloakApplicationTests {

	@Test
	void contextLoads() {
	}

}
