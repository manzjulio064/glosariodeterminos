package com.dh.subscriptionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubscriptionServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
