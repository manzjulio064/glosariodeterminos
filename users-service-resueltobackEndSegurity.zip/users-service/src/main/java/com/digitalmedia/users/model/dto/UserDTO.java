package com.digitalmedia.users.model.dto;

public class UserDTO {

  private String email;
  private String username;

  public UserDTO(String email, String username) {
    this.email = email;
    this.username = username;
  }
}
